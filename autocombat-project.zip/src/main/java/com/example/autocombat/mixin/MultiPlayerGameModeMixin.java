package com.example.autocombat.mixin;

import com.example.autocombat.EatState;

import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MultiPlayerGameMode.class)
public abstract class MultiPlayerGameModeMixin {

    // バニラは「使用キー(右クリック)を押していない」と、毎tick食事を中断する。
    // Modが食べている間だけ、その中断を止める。（使用キーを押したことにしないので、食後の誤爆が起きない）
    @Inject(method = "releaseUsingItem", at = @At("HEAD"), cancellable = true)
    private void autocombat$keepEating(Player player, CallbackInfo ci) {
        if (EatState.eating && player.isUsingItem() && player.getUsedItemHand() == InteractionHand.OFF_HAND) {
            ci.cancel();
        }
    }
}
