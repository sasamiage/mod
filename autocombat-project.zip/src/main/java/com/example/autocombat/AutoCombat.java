package com.example.autocombat;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.CompletableFuture;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.ResourceLocationArgument;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.EntityHitResult;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModList;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.loading.FMLPaths;
import net.neoforged.neoforge.client.ClientCommandHandler;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterClientCommandsEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.common.NeoForge;

/**
 * クライアント専用Mod。
 *  - 照準が生き物に合っている間、何も押さなくても、攻撃クールダウンが溜まった瞬間に自動で攻撃
 *  - オフハンドの食べ物を、「満腹度がその食べ物の回復量ぶん減ったとき」に自動で食べる（全ての食べ物に対応）
 *  - オフハンドの食べ物が切れたら、インベントリの同じ食べ物をオフハンドへ移す。無ければ自動攻撃を停止
 *  - 指定したアイテムがインベントリに入ったら自動で捨てる（インベントリを開いていても動く）
 *  - Createが入っていれば、ワールドに入ったとき /flywheel backend off を自動で実行
 *  - キー(K / J) または /autocombat コマンドで ON/OFF
 */
@Mod(value = AutoCombat.MOD_ID, dist = Dist.CLIENT)
public class AutoCombat {
    public static final String MOD_ID = "autocombat";

    private static final String CATEGORY = "key.categories.autocombat";
    private static final KeyMapping TOGGLE_ATTACK =
            new KeyMapping("key.autocombat.toggle_attack", InputConstants.KEY_K, CATEGORY);
    private static final KeyMapping TOGGLE_EAT =
            new KeyMapping("key.autocombat.toggle_eat", InputConstants.KEY_J, CATEGORY);

    private static boolean autoAttack = true;
    private static boolean autoEat = true;
    private static boolean autoDrop = true;
    /** 毒や空腹などの悪い効果がある食べ物・コーラスフルーツ・怪しげなシチューも食べるか */
    private static boolean eatHarmful = false;
    private static boolean debug = false;
    /** ワールドに入ったとき、Createが入っていれば /flywheel backend off を自動で実行するか */
    private static boolean flywheelOff = true;
    private static int flywheelDelay = -1;

    /** 自動で捨てるアイテムのID一覧 */
    private static final Set<ResourceLocation> DROP_IDS = new LinkedHashSet<>();

    private static int eatTicks = 0;
    private static int eatCooldown = 0;
    private static Item lastOffhandFood = null;
    private static int refillCooldown = 0;
    private static int dropCooldown = 0;

    public AutoCombat(IEventBus modEventBus) {
        load();
        modEventBus.addListener(AutoCombat::onRegisterKeys);
        NeoForge.EVENT_BUS.addListener(AutoCombat::onClientTick);
        NeoForge.EVENT_BUS.addListener(AutoCombat::onLoggingIn);
        NeoForge.EVENT_BUS.addListener(AutoCombat::onRegisterCommands);
    }

    private static void onRegisterKeys(RegisterKeyMappingsEvent event) {
        event.register(TOGGLE_ATTACK);
        event.register(TOGGLE_EAT);
    }

    private static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.level == null || mc.gameMode == null) {
            EatState.eating = false;
            lastOffhandFood = null;
            return;
        }

        // ワールドに入ってから少し待って、Flywheelのバックエンドをオフにする
        if (flywheelDelay > 0 && --flywheelDelay == 0) {
            runFlywheelOff();
        }

        while (TOGGLE_ATTACK.consumeClick()) {
            setAutoAttack(!autoAttack);
        }
        while (TOGGLE_EAT.consumeClick()) {
            setAutoEat(!autoEat);
        }

        if (debug) {
            String target = mc.hitResult instanceof EntityHitResult h
                    ? h.getEntity().getType().getDescriptionId()
                    : (mc.hitResult == null ? "なし" : String.valueOf(mc.hitResult.getType()));
            message("攻撃キー:" + mc.options.keyAttack.isDown()
                    + " 対象:" + target
                    + " CD:" + String.format("%.2f", player.getAttackStrengthScale(0.0F))
                    + " 使用中:" + player.isUsingItem()
                    + " 画面:" + (mc.screen != null));
        }

        // 自動で捨てるのは、インベントリなどの画面を開いていても動く
        handleDrop(mc, player);

        if (mc.screen != null) return;

        handleFoodSupply(mc, player);
        handleEating(mc, player);
        handleAttack(mc, player);
    }

    // ---------------- 自動攻撃 ----------------
    private static void handleAttack(Minecraft mc, LocalPlayer player) {
        if (!autoAttack) return;
        if (player.isUsingItem() || player.isSpectator()) return;
        if (!(mc.hitResult instanceof EntityHitResult hit)) return;
        Entity target = hit.getEntity();
        if (!(target instanceof LivingEntity) || !target.isAttackable()) return; // 生き物だけ
        if (target instanceof TamableAnimal pet && pet.isOwnedBy(player)) return; // 自分のペットは殴らない
        if (player.getAttackStrengthScale(0.0F) < 1.0F) return; // クールダウンが溜まった瞬間

        mc.gameMode.attack(player, target);
        player.swing(InteractionHand.MAIN_HAND);
    }

    // ---------------- 自動食事 ----------------
    private static void handleEating(Minecraft mc, LocalPlayer player) {
        if (EatState.eating) {
            // 食べている間は、バニラの「右クリックを離したので中断」をMixinで止めている。
            // 使用キーは押したことにしないので、食べ終わったあとに右クリックが残らない。
            if (player.isUsingItem() && player.getUsedItemHand() == InteractionHand.OFF_HAND && ++eatTicks < 100) {
                return;
            }
            EatState.eating = false;
            eatTicks = 0;
            eatCooldown = 10;
        }

        if (eatCooldown > 0) {
            eatCooldown--;
            return;
        }
        if (!autoEat || player.isUsingItem() || player.isSpectator()) return;

        ItemStack offhand = player.getOffhandItem();
        FoodProperties food = offhand.get(DataComponents.FOOD);
        if (food == null || food.nutrition() <= 0) return;
        if (!eatHarmful && isHarmful(offhand, food)) return;

        // 満腹度が、その食べ物の回復量ぶん（以上）減っていたら食べる
        if (20 - player.getFoodData().getFoodLevel() < food.nutrition()) return;

        mc.gameMode.useItem(player, InteractionHand.OFF_HAND);
        if (player.isUsingItem()) {
            EatState.eating = true;
            eatTicks = 0;
        }
        eatCooldown = 20;
    }

    /** 悪い効果がある食べ物か（毒・空腹・コーラスフルーツ・怪しげなシチュー） */
    private static boolean isHarmful(ItemStack stack, FoodProperties food) {
        if (stack.is(Items.CHORUS_FRUIT) || stack.is(Items.SUSPICIOUS_STEW)) return true;
        for (FoodProperties.PossibleEffect possible : food.effects()) {
            if (possible.effect().getEffect().value().getCategory() == MobEffectCategory.HARMFUL) {
                return true;
            }
        }
        return false;
    }

    // ---------------- 食べ物の補充 ----------------
    /** オフハンドの食べ物が切れたら、インベントリの同じ食べ物をオフハンドに移す。無ければ自動攻撃を止める */
    private static void handleFoodSupply(Minecraft mc, LocalPlayer player) {
        if (!autoEat) {
            lastOffhandFood = null;
            return;
        }
        ItemStack off = player.getOffhandItem();
        if (off.get(DataComponents.FOOD) != null) {
            lastOffhandFood = off.getItem();
            return;
        }
        if (lastOffhandFood == null) return;
        if (!off.isEmpty()) {          // 自分で別のアイテムに持ち替えたときは何もしない
            lastOffhandFood = null;
            return;
        }
        if (player.isUsingItem()) return;
        if (refillCooldown > 0) {
            refillCooldown--;
            return;
        }

        int slot = findMenuSlot(player, lastOffhandFood);
        if (slot >= 0) {
            // ClickType.SWAP + ボタン40 = そのスロットとオフハンドを入れ替える
            mc.gameMode.handleInventoryMouseClick(player.inventoryMenu.containerId, slot, 40, ClickType.SWAP, player);
            refillCooldown = 10;
        } else {
            lastOffhandFood = null;
            if (autoAttack) {
                autoAttack = false;
                save();
                message("食べ物が切れたので自動攻撃を停止しました");
            }
        }
    }

    /** インベントリ内で指定アイテムがあるスロット（メニュー上の番号）を返す。無ければ -1 */
    private static int findMenuSlot(LocalPlayer player, Item item) {
        List<ItemStack> items = player.getInventory().items;
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).is(item)) {
                return i < 9 ? i + 36 : i; // ホットバー(0-8)はメニューでは36-44
            }
        }
        return -1;
    }

    // ---------------- 自動で捨てる ----------------
    private static void handleDrop(Minecraft mc, LocalPlayer player) {
        if (!autoDrop || DROP_IDS.isEmpty()) return;
        if (dropCooldown > 0) {
            dropCooldown--;
            return;
        }
        if (player.isUsingItem() || player.isSpectator()) return;
        if (mc.screen instanceof CreativeModeInventoryScreen) return;

        // 今開いているメニュー（インベントリ・チェストなど）の中の、自分のインベントリ部分だけを見る
        AbstractContainerMenu menu = player.containerMenu;
        if (!menu.getCarried().isEmpty()) return;

        for (Slot slot : menu.slots) {
            if (slot.container != player.getInventory()) continue;
            if (slot.getContainerSlot() >= 36) continue; // 防具・オフハンドは対象外
            ItemStack stack = slot.getItem();
            if (stack.isEmpty()) continue;
            if (!DROP_IDS.contains(BuiltInRegistries.ITEM.getKey(stack.getItem()))) continue;

            // ClickType.THROW + ボタン1 = スタック全部を捨てる
            mc.gameMode.handleInventoryMouseClick(menu.containerId, slot.index, 1, ClickType.THROW, player);
            dropCooldown = 4;
            return;
        }
    }

    // ---------------- Flywheel ----------------
    /** ワールド(サーバー)に入ったとき */
    private static void onLoggingIn(ClientPlayerNetworkEvent.LoggingIn event) {
        if (flywheelOff && ModList.get().isLoaded("create")) {
            // クライアントコマンドの準備が終わるのを待つため、少し(約3秒)あとに実行する
            flywheelDelay = 60;
        }
    }

    /** /flywheel backend off を、チャットで打ったときと同じように実行する */
    private static void runFlywheelOff() {
        boolean handled = false;
        try {
            handled = ClientCommandHandler.runCommand("flywheel backend off");
        } catch (RuntimeException ignored) {
            // 失敗しても、ゲームは続ける
        }
        if (!handled) {
            chat("/flywheel backend off を実行できなかった（Flywheelが入っていない？）");
        }
    }

    // ---------------- ON/OFF ----------------
    private static void setAutoAttack(boolean value) {
        autoAttack = value;
        save();
        message("自動攻撃: " + (value ? "ON" : "OFF"));
    }

    private static void setAutoEat(boolean value) {
        autoEat = value;
        save();
        message("自動食事: " + (value ? "ON" : "OFF"));
    }

    private static void setEatHarmful(boolean value) {
        eatHarmful = value;
        save();
        message("悪い効果のある食べ物も食べる: " + (value ? "ON" : "OFF"));
    }

    private static void setFlywheelOff(boolean value) {
        flywheelOff = value;
        save();
        message("ワールドに入ったとき /flywheel backend off: " + (value ? "ON" : "OFF"));
    }

    private static void setAutoDrop(boolean value) {
        autoDrop = value;
        save();
        message("自動で捨てる: " + (value ? "ON" : "OFF"));
    }

    /** 画面下(アクションバー)に表示 */
    private static void message(String text) {
        LocalPlayer player = Minecraft.getInstance().player;
        if (player != null) {
            player.displayClientMessage(Component.literal(text), true);
        }
    }

    /** チャット欄に表示 */
    private static void chat(String text) {
        LocalPlayer player = Minecraft.getInstance().player;
        if (player != null) {
            player.displayClientMessage(Component.literal(text), false);
        }
    }

    // ---------------- 捨てるアイテムの設定 ----------------
    private static int dropAdd(ResourceLocation id) {
        Optional<Item> item = BuiltInRegistries.ITEM.getOptional(id);
        if (item.isEmpty() || item.get() == Items.AIR) {
            chat("そのアイテムは見つからない: " + id);
            return 0;
        }
        ResourceLocation key = BuiltInRegistries.ITEM.getKey(item.get());
        if (DROP_IDS.add(key)) {
            save();
            chat("捨てる対象に追加: " + key);
        } else {
            chat("すでに登録済み: " + key);
        }
        return 1;
    }

    private static int dropRemove(ResourceLocation id) {
        if (DROP_IDS.remove(id)) {
            save();
            chat("捨てる対象から削除: " + id);
            return 1;
        }
        chat("登録されていない: " + id);
        return 0;
    }

    private static ResourceLocation mainHandId() {
        LocalPlayer player = Minecraft.getInstance().player;
        if (player == null) return null;
        ItemStack stack = player.getMainHandItem();
        if (stack.isEmpty()) {
            chat("メインハンドに何も持ってない");
            return null;
        }
        return BuiltInRegistries.ITEM.getKey(stack.getItem());
    }

    private static int dropAddHand() {
        ResourceLocation id = mainHandId();
        return id == null ? 0 : dropAdd(id);
    }

    private static int dropRemoveHand() {
        ResourceLocation id = mainHandId();
        return id == null ? 0 : dropRemove(id);
    }

    private static int dropList() {
        if (DROP_IDS.isEmpty()) {
            chat("自動で捨てるアイテム: なし（自動で捨てる: " + (autoDrop ? "ON" : "OFF") + "）");
        } else {
            chat("自動で捨てるアイテム（自動で捨てる: " + (autoDrop ? "ON" : "OFF") + "）");
            for (ResourceLocation id : DROP_IDS) {
                chat(" - " + id);
            }
        }
        return 1;
    }

    private static int dropClear() {
        DROP_IDS.clear();
        save();
        chat("捨てるアイテムの登録を全部消した");
        return 1;
    }

    private static CompletableFuture<Suggestions> suggestItems(
            CommandContext<CommandSourceStack> ctx, SuggestionsBuilder builder) {
        return SharedSuggestionProvider.suggestResource(BuiltInRegistries.ITEM.keySet(), builder);
    }

    private static CompletableFuture<Suggestions> suggestRegistered(
            CommandContext<CommandSourceStack> ctx, SuggestionsBuilder builder) {
        return SharedSuggestionProvider.suggestResource(DROP_IDS, builder);
    }

    private static void onRegisterCommands(RegisterClientCommandsEvent event) {
        event.getDispatcher().register(
                Commands.literal("autocombat")
                        .then(Commands.literal("attack")
                                .executes(c -> { setAutoAttack(!autoAttack); return 1; })
                                .then(Commands.literal("on").executes(c -> { setAutoAttack(true); return 1; }))
                                .then(Commands.literal("off").executes(c -> { setAutoAttack(false); return 1; })))
                        .then(Commands.literal("eat")
                                .executes(c -> { setAutoEat(!autoEat); return 1; })
                                .then(Commands.literal("on").executes(c -> { setAutoEat(true); return 1; }))
                                .then(Commands.literal("off").executes(c -> { setAutoEat(false); return 1; }))
                                .then(Commands.literal("harmful")
                                        .then(Commands.literal("on").executes(c -> { setEatHarmful(true); return 1; }))
                                        .then(Commands.literal("off").executes(c -> { setEatHarmful(false); return 1; }))))
                        .then(Commands.literal("drop")
                                .then(Commands.literal("on").executes(c -> { setAutoDrop(true); return 1; }))
                                .then(Commands.literal("off").executes(c -> { setAutoDrop(false); return 1; }))
                                .then(Commands.literal("list").executes(c -> dropList()))
                                .then(Commands.literal("clear").executes(c -> dropClear()))
                                .then(Commands.literal("add")
                                        .executes(c -> dropAddHand())
                                        .then(Commands.argument("item", ResourceLocationArgument.id())
                                                .suggests(AutoCombat::suggestItems)
                                                .executes(c -> dropAdd(ResourceLocationArgument.getId(c, "item")))))
                                .then(Commands.literal("remove")
                                        .executes(c -> dropRemoveHand())
                                        .then(Commands.argument("item", ResourceLocationArgument.id())
                                                .suggests(AutoCombat::suggestRegistered)
                                                .executes(c -> dropRemove(ResourceLocationArgument.getId(c, "item")))))
                                .executes(c -> dropList()))
                        .then(Commands.literal("flywheel")
                                .then(Commands.literal("on").executes(c -> { setFlywheelOff(true); return 1; }))
                                .then(Commands.literal("off").executes(c -> { setFlywheelOff(false); return 1; }))
                                .then(Commands.literal("run").executes(c -> { runFlywheelOff(); return 1; }))
                                .executes(c -> { setFlywheelOff(!flywheelOff); return 1; }))
                        .then(Commands.literal("debug").executes(c -> {
                            debug = !debug;
                            message("デバッグ表示: " + (debug ? "ON" : "OFF"));
                            return 1;
                        }))
                        .executes(c -> {
                            chat("自動攻撃: " + (autoAttack ? "ON" : "OFF")
                                    + " / 自動食事: " + (autoEat ? "ON" : "OFF")
                                    + "（悪い効果のある食べ物: " + (eatHarmful ? "食べる" : "食べない") + "）"
                                    + " / 自動で捨てる: " + (autoDrop ? "ON" : "OFF")
                                    + "（" + DROP_IDS.size() + "種類）"
                                    + " / 入室時にFlywheelオフ: " + (flywheelOff ? "ON" : "OFF")
                                    + "（Create: " + (ModList.get().isLoaded("create") ? "あり" : "なし") + "）");
                            return 1;
                        }));
    }

    // ---------------- 設定の保存・読み込み ----------------
    private static Path configPath() {
        return FMLPaths.CONFIGDIR.get().resolve("autocombat-client.txt");
    }

    private static void save() {
        try {
            List<String> lines = new ArrayList<>();
            lines.add("attack=" + autoAttack);
            lines.add("eat=" + autoEat);
            lines.add("harmful=" + eatHarmful);
            lines.add("drop=" + autoDrop);
            lines.add("flywheel=" + flywheelOff);
            for (ResourceLocation id : DROP_IDS) {
                lines.add("item=" + id);
            }
            Files.write(configPath(), lines, StandardCharsets.UTF_8);
        } catch (IOException | RuntimeException ignored) {
            // 保存に失敗してもゲームは続ける
        }
    }

    private static void load() {
        try {
            Path path = configPath();
            if (!Files.exists(path)) return;
            for (String line : Files.readAllLines(path, StandardCharsets.UTF_8)) {
                int eq = line.indexOf('=');
                if (eq < 0) continue;
                String key = line.substring(0, eq).trim();
                String value = line.substring(eq + 1).trim();
                switch (key) {
                    case "attack" -> autoAttack = Boolean.parseBoolean(value);
                    case "eat" -> autoEat = Boolean.parseBoolean(value);
                    case "harmful" -> eatHarmful = Boolean.parseBoolean(value);
                    case "drop" -> autoDrop = Boolean.parseBoolean(value);
                    case "flywheel" -> flywheelOff = Boolean.parseBoolean(value);
                    case "item" -> {
                        ResourceLocation id = ResourceLocation.tryParse(value);
                        if (id != null) DROP_IDS.add(id);
                    }
                    default -> { }
                }
            }
        } catch (IOException | RuntimeException ignored) {
            // 読み込みに失敗したら初期設定のまま
        }
    }
}
