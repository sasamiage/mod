package com.example.autocombat;

/** 「Modが食事中」かどうかを、Mixinと共有するための旗 */
public final class EatState {
    public static volatile boolean eating = false;

    private EatState() {}
}
